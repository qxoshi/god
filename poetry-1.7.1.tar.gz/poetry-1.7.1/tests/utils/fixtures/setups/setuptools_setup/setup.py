from __future__ import annotations

import setuptools


setuptools.setup(
    name="my_package",
    version="0.1.2",
    author="John Doe",
    author_email="john@example.orh",
    description="Just a description",
    url="https://example.org",
    packages=setuptools.find_packages(),
)
